import Layout from '../components/Layout';
export default function Home(){return (<Layout><p>Welcome to the ZumTV Admin Panel.</p></Layout>)}